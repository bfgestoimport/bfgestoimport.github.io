import Layout from "@/components/Layout";


const Nosotros = () => (
  <Layout>
    {/* HERO — full red with geometric shapes */}
    <section className="relative bg-[hsl(var(--red))] text-white py-28 overflow-hidden">
      <div className="absolute top-0 right-0 w-[40%] h-44 blob-gold rounded-bl-[100px]" aria-hidden />
      <div className="absolute bottom-0 left-0 w-48 h-32 blob-burgundy rounded-tr-[90px]" aria-hidden />

      <div className="relative container-x">
        <div className="section-label !text-white/90">Sobre nosotros</div>
        <h1 className="text-white max-w-5xl animate-fade-in-up">
          Detrás de cada envío,<br />
          <span className="text-brand-mint">hay un equipo que</span><br />
          <span className="text-brand-mint">conoce el camino.</span>
        </h1>
      </div>
    </section>

    {/* EL GRUPO — white */}
    <section className="bg-white py-24">
      <div className="container-x grid md:grid-cols-12 gap-12">
        <div className="md:col-span-4">
          <div className="section-label" style={{ color: "hsl(var(--red))" }}>El grupo</div>
          <h2 className="text-brand-navy">Especialistas, no genéricos.</h2>
        </div>
        <div className="md:col-span-8 space-y-6 text-lg text-brand-mid leading-relaxed">
          <p>
            BF Gesto nació de la necesidad real de empresarios dominicanos de tener un socio confiable en la cadena de importación, en la logística internacional y en la comercialización de materiales reciclables. No somos intermediarios genéricos. Somos especialistas en industrias donde los errores cuestan caro.
          </p>
          <p>
            Operamos en dos frentes complementarios: servicios marítimos e importación desde China, y comercialización a gran escala de chatarra ferrosa, no ferrosa, cartón y plásticos reciclados.
          </p>
        </div>
      </div>
    </section>

    {/* FILOSOFIA — red section with white cards */}
    <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-24 blob-burgundy rounded-bl-[60px]" aria-hidden />
      <div className="absolute bottom-0 left-0 w-40 h-28 blob-gold rounded-tr-[80px]" aria-hidden />

      <div className="container-x relative">
        <div className="section-label">Filosofía</div>
        <h2 className="text-white mb-14 max-w-3xl">Tres reglas. Cero excusas.</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { n: "01.", t: "Directo", d: "Todo proceso tiene un responsable y un plazo. Sin ambigüedad, sin excusas." },
            { n: "02.", t: "Especializado", d: "Cada empresa del grupo tiene foco. No hacemos de todo. Hacemos bien lo que hacemos." },
            { n: "03.", t: "Medible", d: "Nuestros clientes saben qué esperan recibir y cuándo. Eso no es opcional." },
          ].map((c) => (
            <div key={c.t} className="card-on-red">
              <div className="step-number mb-3">{c.n}</div>
              <h3 className="text-brand-navy mb-3 text-xl">{c.t}</h3>
              <p className="text-brand-mid leading-relaxed">{c.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* PRESENCIA — white */}
    <section className="bg-white py-24">
      <div className="container-x">
        <div className="section-label" style={{ color: "hsl(var(--red))" }}>Presencia</div>
        <h2 className="text-brand-navy mb-12">Donde operamos.</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { p: "República Dominicana", d: "Sede operativa, oficinas comerciales y planta de procesamiento de reciclables." },
            { p: "China", d: "Verificación de proveedores, coordinación de envíos y almacenaje." },
            { p: "Mercados de exportación", d: "Clientes industriales internacionales para metales y materiales reciclables." },
          ].map((c) => (
            <div key={c.p} className="border-t-[6px] border-brand-red pt-6">
              <h3 className="text-brand-navy mb-3 text-xl">{c.p}</h3>
              <p className="text-brand-mid leading-relaxed">{c.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </Layout>
);

export default Nosotros;
