import Layout from "@/components/Layout";

import { Link } from "react-router-dom";
import {
  ShieldCheck, Ship, FileText, Warehouse, Container, Compass,
  Recycle, Boxes, Package, Layers, ArrowRight, Plane, Truck,
} from "lucide-react";
import portChina from "@/assets/port-china.jpg";

const services = [
  { Icon: ShieldCheck, t: "Verificación de Proveedores", d: "Evaluación exhaustiva de reputación, capacidad productiva e historial de exportación. Hacemos la investigación antes de que pongas un centavo." },
  { Icon: Ship, t: "Gestión de Envíos", d: "Coordinación de envíos marítimos y aéreos. Evaluamos navieras por precio, tiempo de tránsito y confiabilidad. Tú eliges." },
  { Icon: FileText, t: "Gestiones Aduanales", d: "Preparación de documentación necesaria para cumplir con regulaciones locales y manejo completo del proceso aduanal." },
  { Icon: Warehouse, t: "Almacenaje en China", d: "Servicios de almacenamiento en instalaciones seguras y estratégicamente ubicadas. Inventario controlado, distribución a tu ritmo." },
  { Icon: Container, t: "Contenedores Consolidados", d: "Alquiler de espacios dentro de contenedores para optimizar costos de envío sin sacrificar frecuencia." },
  { Icon: Compass, t: "Asesoría Personalizada", d: "Análisis de necesidades específicas. Asesoramiento en negociación de términos, precios, plazos y condiciones de pago." },
];

const reciclables = [
  { Icon: Layers, t: "Chatarra Ferrosa", d: "Compra y suministro de hierro y acero en distintas presentaciones para fundición y exportación." },
  { Icon: Recycle, t: "Chatarra No Ferrosa", d: "Cobre, aluminio, bronce y otros metales no ferrosos para mercados industriales." },
  { Icon: Boxes, t: "Cartón Reciclado", d: "Acopio y comercialización de cartón en grandes volúmenes para la industria papelera." },
  { Icon: Package, t: "Plásticos Reciclados", d: "PET, HDPE, PP y otros polímeros en todas sus presentaciones, para reprocesamiento industrial." },
];

const BfGestoImport = () => (
  <Layout>
    {/* HERO */}
    <section className="relative h-[80vh] min-h-[560px] overflow-hidden">
      <video className="absolute inset-0 w-full h-full object-cover z-0" autoPlay muted loop playsInline>
        <source src="https://ik.imagekit.io/rqabtyp51t/0416.mp4" type="video/mp4" />
      </video>
      <div className="absolute inset-0 bg-[hsl(var(--red))]/80 z-10" />

      <div className="absolute top-0 right-0 w-[42%] h-44 blob-gold rounded-bl-[120px] z-20" aria-hidden />
      <div className="absolute bottom-0 left-0 w-56 h-36 blob-burgundy rounded-tr-[100px] z-20" aria-hidden />

      <div className="relative z-30 container-x h-full flex flex-col justify-center text-white">
        <div className="section-label !text-white/90">BF Gesto Import</div>
        <h1 className="text-white max-w-5xl animate-fade-in-up delay-150">
          Importar desde China<br/>
          <span className="text-brand-mint">no tiene que ser</span><br/>
          <span className="text-brand-mint">complicado.</span>
        </h1>
        <p className="mt-8 max-w-2xl text-lg md:text-xl text-white/95 animate-fade-in-up delay-300 leading-relaxed">
          Manejamos proveedores, envíos, aduanas y almacenaje. Y comercializamos materiales reciclables a gran escala.
        </p>
      </div>
    </section>

    {/* SOBRE NOSOTROS — replicating slide 2 */}
    <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-[36%] h-44 blob-gold rounded-bl-[100px]" aria-hidden />
      <div className="absolute bottom-0 left-0 w-40 h-32 blob-burgundy rounded-tr-[80px]" aria-hidden />

      <div className="relative container-x grid md:grid-cols-2 gap-14 items-center">
        <div>
          <h2 className="text-white mb-8">Sobre Nosotros</h2>
          <p className="text-lg leading-relaxed text-white/95 mb-6">
            BF Gesto Import es una empresa líder en la gestión de importaciones desde China, dedicada a ofrecer soluciones integrales para facilitar el comercio internacional. Nos especializamos en la verificación exhaustiva de proveedores, garantizando relaciones comerciales con socios confiables y de calidad.
          </p>
          <div className="h-px bg-white/30 my-6" />
          <p className="text-lg leading-relaxed text-white/95">
            Nuestro servicio incluye gestión de envíos y permisos aduanales, asegurando que cada operación cumpla con las normativas vigentes. Ofrecemos almacenaje en China y alquiler de espacios en contenedores consolidados para mayor eficiencia en el manejo de cargas.
          </p>
        </div>
        <div className="relative">
          <div className="absolute -top-6 -right-6 w-24 h-24 bg-brand-burgundy rounded-tl-[60px]" aria-hidden />
          <img
            src={portChina}
            alt="Puerto en China con grúas y contenedores"
            className="relative w-full h-[460px] object-cover rounded-l-[80px] shadow-2xl"
            loading="lazy"
            width={1920}
            height={1080}
          />
        </div>
      </div>
    </section>

    {/* DOS LÍNEAS */}
    <section className="bg-brand-off py-20">
      <div className="container-x grid md:grid-cols-2 gap-8">
        <div className="card-light p-10 border-l-[6px] border-brand-red">
          <div className="section-label" style={{ color: "hsl(var(--red))" }}>Línea 01</div>
          <h3 className="text-2xl font-black uppercase text-brand-navy mb-3">Logística e Importación</h3>
          <p className="text-brand-mid leading-relaxed">
            Servicios marítimos, aéreos y terrestres. Verificación de proveedores en China, gestión aduanal y almacenaje. Operación end-to-end.
          </p>
        </div>
        <div className="card-light p-10 border-l-[6px] border-brand-mint-deep">
          <div className="section-label" style={{ color: "hsl(var(--mint-deep))" }}>Línea 02</div>
          <h3 className="text-2xl font-black uppercase text-brand-navy mb-3">Comercialización de Reciclables</h3>
          <p className="text-brand-mid leading-relaxed">
            Compra, acopio y suministro a gran escala de chatarra ferrosa y no ferrosa, cartón y plásticos reciclados en todas sus presentaciones.
          </p>
        </div>
      </div>
    </section>

    {/* SERVICIOS — RED block, 3-column flow with medallion icons (replicating slide 3) */}
    <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-24 blob-burgundy rounded-bl-[60px]" aria-hidden />
      <div className="container-x relative">
        <div className="text-center mb-16">
          <div className="section-label">Lo que hacemos</div>
          <h2 className="text-white">Servicios</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-6">
          {services.slice(0, 3).map(({ Icon, t, d }, i) => (
            <div key={t} className="flex flex-col items-center text-center relative">
              <div className="icon-medallion mb-6">
                <Icon size={36} strokeWidth={2} />
              </div>
              {i < 2 && (
                <div className="hidden md:block absolute top-12 -right-4 text-white/60 text-2xl tracking-widest">· · · · ▶</div>
              )}
              <h3 className="text-white mb-3 text-xl">{t}</h3>
              <p className="text-white/90 text-sm md:text-base leading-relaxed max-w-xs">{d}</p>
            </div>
          ))}
        </div>

        {/* Second row */}
        <div className="grid md:grid-cols-3 gap-8 md:gap-6 mt-16 pt-16 border-t border-white/15">
          {services.slice(3).map(({ Icon, t, d }) => (
            <div key={t} className="flex flex-col items-center text-center">
              <div className="icon-medallion mb-6">
                <Icon size={36} strokeWidth={2} />
              </div>
              <h3 className="text-white mb-3 text-xl">{t}</h3>
              <p className="text-white/90 text-sm md:text-base leading-relaxed max-w-xs">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* SERVICIOS LOGÍSTICOS — slide 5 replica: 3 modes */}
    <section className="bg-white py-24">
      <div className="container-x">
        <div className="text-center mb-16">
          <div className="section-label" style={{ color: "hsl(var(--red))" }}>Adaptamos las necesidades requeridas</div>
          <h2 className="text-brand-navy">Servicios Logísticos</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { Icon: Truck, t: "Viaje Terrestre", d: "Transporte por carretera para distribución eficiente en cualquier ruta." },
            { Icon: Ship, t: "Viaje Marítimo", d: "Selección de mejores navieras, tarifas competitivas y rutas óptimas." },
            { Icon: Plane, t: "Viaje Aéreo", d: "Envíos urgentes y de alto valor con tiempos de entrega óptimos." },
          ].map(({ Icon, t, d }) => (
            <div key={t} className="card-light text-center border-l-[6px] border-brand-red">
              <div className="icon-medallion mx-auto mb-6">
                <Icon size={36} strokeWidth={2} />
              </div>
              <h3 className="text-brand-navy mb-3 text-xl">{t}</h3>
              <p className="text-brand-mid leading-relaxed">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* MATERIALES RECICLABLES */}
    <section className="bg-brand-off py-24">
      <div className="container-x">
        <div className="section-label" style={{ color: "hsl(var(--red))" }}>Materiales Reciclables</div>
        <h2 className="text-brand-navy mb-4 max-w-3xl">Compra y suministro a gran escala.</h2>
        <p className="text-lg text-brand-mid max-w-3xl mb-14 leading-relaxed">
          Operamos como contraparte comercial confiable para industrias que necesitan colocar o adquirir materiales reciclables en volumen.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reciclables.map(({ Icon, t, d }) => (
            <div key={t} className="card-light border-l-[6px] border-brand-mint-deep text-center">
              <div className="icon-medallion mx-auto mb-5" style={{ width: 76, height: 76 }}>
                <Icon size={28} strokeWidth={2} />
              </div>
              <h3 className="text-brand-navy mb-3">{t}</h3>
              <p className="text-brand-mid leading-relaxed text-[0.95rem]">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* POR QUÉ ELEGIRNOS — slide 7 replica */}
    <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-[36%] h-44 blob-gold rounded-bl-[100px]" aria-hidden />
      <div className="absolute bottom-0 left-0 w-48 h-32 blob-burgundy rounded-tr-[80px]" aria-hidden />

      <div className="relative container-x grid md:grid-cols-2 gap-14">
        <div>
          <h2 className="text-white mb-6">¿Por qué<br/>elegirnos?</h2>
          <p className="text-lg text-white/95 leading-relaxed max-w-md">
            Elige BF Gesto Import y experimenta la diferencia de trabajar con un socio confiable y comprometido con tu éxito.
          </p>
        </div>
        <div className="space-y-8">
          {[
            ["01.", "Experiencia y Conocimiento", "Equipo de expertos en comercio internacional con años de experiencia en importaciones desde China."],
            ["02.", "Verificación Rigurosa", "Auditamos proveedores antes de mover capital, garantizando socios confiables y de calidad."],
            ["03.", "Soluciones Personalizadas", "Asesoría adaptada a tus necesidades, desde selección de proveedores hasta logística de entrega."],
            ["04.", "Transparencia en Procesos", "Comunicación clara en cada etapa. Siempre estás al tanto del estado de tus importaciones."],
          ].map(([n, t, d]) => (
            <div key={n} className="flex gap-5">
              <span className="step-number flex-shrink-0">{n}</span>
              <div>
                <h3 className="text-white text-lg mb-2">{t}</h3>
                <p className="text-white/85 leading-relaxed text-[0.95rem]">{d}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* SECTORES — pills */}
    <section className="bg-brand-off py-24">
      <div className="container-x">
        <div className="section-label" style={{ color: "hsl(var(--red))" }}>¿Quién nos contrata?</div>
        <h2 className="text-brand-navy mb-10 max-w-3xl">Sectores que atendemos.</h2>
        <div className="flex flex-wrap gap-3">
          {[
            "Retailers",
            "Constructoras",
            "Importadores independientes",
            "Distribuidores",
            "Empresas manufactureras",
            "Emprendedores que importan por primera vez",
            "Industrias procesadoras de metales",
            "Plantas de reciclaje",
          ].map((s) => (
            <span key={s} className="pill">{s}</span>
          ))}
        </div>
      </div>
    </section>

    {/* CTA */}
    <section id="contacto" className="bg-brand-navy text-white py-20 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-24 blob-gold rounded-bl-[60px]" aria-hidden />
      <div className="container-x text-center relative">
        <h2 className="text-white mb-4">Habla con nosotros.</h2>
        <p className="text-xl text-brand-mint mb-10 font-bold">Te tenemos una solución.</p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Link to="/contacto" className="btn-white">Contáctanos <ArrowRight size={18} /></Link>
          <a href="https://wa.me/18297949216" target="_blank" rel="noopener noreferrer" className="btn-outline-white">WhatsApp 1-829-794-9216</a>
        </div>
      </div>
    </section>
  </Layout>
);

export default BfGestoImport;
