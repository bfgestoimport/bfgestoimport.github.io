import Layout from "@/components/Layout";

import { Link } from "react-router-dom";
import {
  Cog, Battery, Wrench, ClipboardList, Recycle, Leaf,
  ShieldCheck, Truck, Phone, Mail, MapPin, Clock, ArrowRight,
} from "lucide-react";
import recyclingYard from "@/assets/recycling-yard.jpg";

const services = [
  { Icon: Cog, t: "Metales Ferrosos y No Ferrosos", d: "Compra, procesamiento y exportación de hierro, cobre, bronce, aluminio, motores eléctricos y calamina." },
  { Icon: Battery, t: "Baterías Húmedas", d: "Recolección, tratamiento y disposición final de baterías húmedas con todos los permisos ambientales vigentes." },
  { Icon: Recycle, t: "Plásticos Reciclables", d: "Procesamos plásticos en distintas presentaciones, integrándolos a nuestra cadena de exportación." },
  { Icon: Wrench, t: "Desmantelamiento Industrial", d: "Compra y venta de desperdicios metálicos. Gestionamos el proceso completo de desmantelamiento." },
  { Icon: ClipboardList, t: "Asesoría en Gestión de Residuos", d: "Orientamos a empresas en recolección, acopio y disposición final de residuos sólidos." },
  { Icon: Truck, t: "Logística de Recolección", d: "Coordinamos la recolección desde tu instalación hasta nuestra planta de 5,000 m² en Pedro Brand." },
];

const valores = [
  "Responsabilidad", "Sentido de Urgencia", "Planificación de Entrega",
  "Autoconvicción de Servicio", "Sentido de Ética", "Objetividad",
  "Dinamismo", "Integridad",
];

const Recicladora = () => (
  <Layout>
    {/* HERO */}
    <section className="relative bg-[hsl(var(--red))] text-white py-28 overflow-hidden">
      <img
        src={recyclingYard}
        alt="Patio de reciclaje industrial"
        className="absolute inset-0 w-full h-full object-cover opacity-20"
        width={1920}
        height={1080}
      />
      <div className="absolute inset-0 bg-[hsl(var(--red))]/80" />
      <div className="absolute top-0 right-0 w-[40%] h-44 blob-gold rounded-bl-[100px] z-10" aria-hidden />
      <div className="absolute bottom-0 left-0 w-48 h-32 blob-burgundy rounded-tr-[90px] z-10" aria-hidden />

      <div className="relative z-20 container-x">
        <div className="section-label !text-white/90">Recicladora Green Resources, SRL</div>
        <h1 className="text-white max-w-5xl animate-fade-in-up">
          Reciclaje responsable<br />
          <span className="text-brand-mint">para un futuro</span><br />
          <span className="text-brand-mint">sostenible.</span>
        </h1>
        <p className="mt-8 max-w-2xl text-lg md:text-xl text-white/95 animate-fade-in-up delay-150">
          Desde 2003 procesamos y exportamos metales ferrosos, no ferrosos, baterías húmedas y plásticos desde Santo Domingo Oeste.
        </p>
        <div className="mt-10 flex flex-wrap gap-4 animate-fade-in-up delay-300">
          <a href="#servicios" className="btn-white">Ver servicios</a>
          <Link to="/contacto" className="btn-outline-white">Contáctanos</Link>
        </div>
      </div>
    </section>

    {/* QUIENES SOMOS — red with image */}
    <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden border-t-4 border-white/10">
      <div className="absolute top-0 right-0 w-32 h-24 blob-burgundy rounded-bl-[60px]" aria-hidden />
      <div className="container-x relative grid md:grid-cols-2 gap-14 items-center">
        <div>
          <h2 className="text-white mb-8">Quiénes Somos</h2>
          <p className="text-lg leading-relaxed text-white/95 mb-6">
            Recicladora Green Resources, SRL nace en 2003 como una empresa familiar con la finalidad de ser pionera en el mercado del reciclaje y disposición de desperdicios sólidos ferrosos, no ferrosos y baterías húmedas en República Dominicana.
          </p>
          <div className="h-px bg-white/30 my-6" />
          <p className="text-lg leading-relaxed text-white/95">
            Desde 2010 contamos con instalaciones de 5,000 m² donde desarrollamos el proceso completo de exportación con el debido tratamiento de materiales ferrosos, no ferrosos, baterías húmedas y plásticos, todo bajo un riguroso nivel de calidad.
          </p>
        </div>
        <div className="relative">
          <div className="absolute -top-6 -right-6 w-24 h-24 bg-brand-burgundy rounded-tl-[60px]" aria-hidden />
          <img
            src={recyclingYard}
            alt="Planta de reciclaje 5,000 m²"
            className="relative w-full h-[460px] object-cover rounded-l-[80px] shadow-2xl"
            loading="lazy"
            width={1920}
            height={1080}
          />
        </div>
      </div>
    </section>

    {/* IMPACTO AMBIENTAL — navy with mint stats */}
    <section className="relative bg-brand-navy text-white py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-44 h-28 blob-gold rounded-bl-[80px]" aria-hidden />
      <div className="container-x relative">
        <div className="section-label">Impacto ambiental</div>
        <h2 className="text-white mb-12 max-w-4xl">El número detrás de cada tonelada que procesamos.</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            ["74%", "Menos energía consumida en fundición vs. mineral virgen."],
            ["40%", "Menos agua que el planeta necesita en el proceso."],
            ["86%", "Reducción de polución del aire y gases de efecto invernadero."],
            ["76%", "Reducción de la contaminación del agua."],
          ].map(([n, d]) => (
            <div key={n} className="bg-white/10 border border-white/15 p-7 rounded-md">
              <div className="text-5xl md:text-6xl font-black text-brand-mint leading-none mb-4">{n}</div>
              <p className="text-sm md:text-base text-white/85 leading-relaxed">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* SERVICIOS — red block with medallion icons */}
    <section id="servicios" className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-24 blob-burgundy rounded-bl-[60px]" aria-hidden />
      <div className="container-x relative">
        <div className="text-center mb-16">
          <div className="section-label">Qué hacemos</div>
          <h2 className="text-white">Servicios</h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map(({ Icon, t, d }) => (
            <div key={t} className="flex flex-col items-center text-center">
              <div className="icon-medallion mb-6">
                <Icon size={36} strokeWidth={2} />
              </div>
              <h3 className="text-white mb-3 text-xl">{t}</h3>
              <p className="text-white/90 text-sm md:text-base leading-relaxed max-w-xs">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* MISIÓN VISIÓN VALORES — light cards */}
    <section className="bg-brand-off py-24">
      <div className="container-x">
        <div className="section-label" style={{ color: "hsl(var(--red))" }}>Identidad</div>
        <h2 className="text-brand-navy mb-12">Misión, Visión y Valores.</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="card-light border-t-[6px] border-brand-red">
            <ShieldCheck className="text-brand-red mb-5" size={32} strokeWidth={1.8} />
            <h3 className="text-brand-navy mb-3 text-xl">Misión</h3>
            <p className="text-brand-mid leading-relaxed">
              Ofertar servicios y productos de alta calidad acorde con los requerimientos de nuestros clientes, priorizando siempre tiempo de entrega y precios accesibles.
            </p>
          </div>
          <div className="card-light border-t-[6px] border-brand-mint-deep">
            <Leaf className="text-brand-mint-deep mb-5" size={32} strokeWidth={1.8} />
            <h3 className="text-brand-navy mb-3 text-xl">Visión</h3>
            <p className="text-brand-mid leading-relaxed">
              Ser líderes proveyendo soluciones estratégicas en gestión de reciclables con equipos de vanguardia, procesos innovadores y materiales de óptima calidad.
            </p>
          </div>
          <div className="card-light border-t-[6px] border-brand-gold">
            <Recycle className="text-brand-gold mb-5" size={32} strokeWidth={1.8} />
            <h3 className="text-brand-navy mb-3 text-xl">Valores</h3>
            <ul className="text-brand-mid leading-relaxed space-y-1.5">
              {valores.map((v) => (
                <li key={v} className="flex items-center gap-2 text-[0.95rem]">
                  <span className="w-1.5 h-1.5 bg-brand-red rounded-full flex-shrink-0" /> {v}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>

    {/* INFO OPERATIVA */}
    <section className="bg-white py-24">
      <div className="container-x">
        <div className="section-label" style={{ color: "hsl(var(--red))" }}>Información operativa</div>
        <h2 className="text-brand-navy mb-12">Visítanos o contáctanos.</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="card-light border-t-[6px] border-brand-red">
            <MapPin className="text-brand-red mb-5" size={28} strokeWidth={1.8} />
            <h3 className="text-brand-navy mb-3">Instalaciones</h3>
            <p className="text-brand-mid leading-relaxed">
              5,000 m²<br />
              Calle Primera No. 1221, Km. 19<br />
              Autopista Duarte, La Guayiga,<br />
              Pedro Brand, Santo Domingo Oeste
            </p>
            <a
              href="https://maps.app.goo.gl/64zDPCHqxrNdWXEz7"
              target="_blank" rel="noopener noreferrer"
              className="inline-block mt-5 text-sm font-extrabold uppercase tracking-wider text-brand-red link-underline"
            >
              Ver en Google Maps →
            </a>
          </div>
          <div className="card-light border-t-[6px] border-brand-red">
            <Clock className="text-brand-red mb-5" size={28} strokeWidth={1.8} />
            <h3 className="text-brand-navy mb-3">Horario</h3>
            <p className="text-brand-mid leading-relaxed">
              <span className="font-bold text-brand-navy">Lunes – Viernes</span><br />
              8:30 AM – 6:00 PM<br /><br />
              <span className="font-bold text-brand-navy">Sábado</span><br />
              8:30 AM – 3:30 PM
            </p>
          </div>
          <div className="card-light border-t-[6px] border-brand-red">
            <Phone className="text-brand-red mb-5" size={28} strokeWidth={1.8} />
            <h3 className="text-brand-navy mb-3">Contacto</h3>
            <p className="text-brand-mid leading-relaxed mb-2">
              <a href="tel:+18097296000" className="text-brand-navy font-semibold link-underline">+1 809 729-6000</a>
            </p>
            <p className="text-brand-mid leading-relaxed flex items-center gap-2">
              <Mail size={16} className="text-brand-red" />
              <a href="mailto:info@recicladora.com.do" className="text-brand-navy font-semibold link-underline">info@recicladora.com.do</a>
            </p>
            <Link to="/contacto" className="btn-red mt-6">
              Hablar con nosotros <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  </Layout>
);

export default Recicladora;
