import Layout from "@/components/Layout";

import { ArrowRight, Mail, Phone, MessageCircle, Instagram, MapPin } from "lucide-react";

const Contacto = () => (
  <Layout>
    {/* HERO */}
    <section className="relative bg-[hsl(var(--red))] text-white py-28 overflow-hidden">
      <div className="absolute top-0 right-0 w-[36%] h-44 blob-gold rounded-bl-[100px]" aria-hidden />
      <div className="absolute bottom-0 left-0 w-48 h-32 blob-burgundy rounded-tr-[90px]" aria-hidden />

      <div className="relative container-x">
        <div className="section-label !text-white/90">Contacto</div>
        <h1 className="text-white max-w-4xl animate-fade-in-up">
          Dinos qué necesitas.<br/>
          <span className="text-brand-mint">Te respondemos en menos de 24 horas.</span>
        </h1>
      </div>
    </section>

    {/* CARDS */}
    <section className="bg-brand-off py-24 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-32 h-24 blob-gold rounded-br-[60px]" aria-hidden />
      <div className="container-x max-w-6xl relative">
        <div className="grid md:grid-cols-2 gap-8 items-stretch">
          {/* BF Gesto Import — left red border */}
          <div className="card-light flex flex-col h-full p-10 border-l-[6px] border-brand-red">
            <div className="flex items-center gap-4 mb-6">
              <div className="icon-medallion" style={{ width: 64, height: 64 }}>
                <MessageCircle size={24} strokeWidth={2} />
              </div>
              <div>
                <div className="text-xs font-extrabold uppercase tracking-[0.18em] text-brand-red mb-1">Importación · Logística · Reciclables</div>
                <h3 className="text-2xl md:text-3xl font-black uppercase text-brand-navy tracking-tight">BF Gesto Import</h3>
              </div>
            </div>
            <ul className="space-y-3 text-brand-mid mb-8 flex-1">
              <li className="flex items-center gap-3">
                <MessageCircle size={18} className="text-brand-red flex-shrink-0" />
                <span>WhatsApp: <a href="https://wa.me/18297949216" target="_blank" rel="noopener noreferrer" className="text-brand-navy font-bold link-underline">1-829-794-9216</a></span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-brand-red flex-shrink-0" />
                <span>Email: <a href="mailto:bfgestoimport@gmail.com" className="text-brand-navy font-bold link-underline">bfgestoimport@gmail.com</a></span>
              </li>
              <li className="flex items-center gap-3">
                <Instagram size={18} className="text-brand-red flex-shrink-0" />
                <span>Instagram: <a href="https://instagram.com/bfgestoimport" target="_blank" rel="noopener noreferrer" className="text-brand-navy font-bold link-underline">@bfgestoimport</a></span>
              </li>
            </ul>
            <a href="mailto:bfgestoimport@gmail.com" className="btn-red self-start">
              Enviar correo <ArrowRight size={18} />
            </a>
          </div>

          {/* Recicladora — left blue/mint border */}
          <div className="card-light flex flex-col h-full p-10 border-l-[6px] border-brand-mint-deep">
            <div className="flex items-center gap-4 mb-6">
              <div className="icon-medallion" style={{ width: 64, height: 64 }}>
                <Phone size={24} strokeWidth={2} />
              </div>
              <div>
                <div className="text-xs font-extrabold uppercase tracking-[0.18em] text-brand-mint-deep mb-1">Reciclaje Industrial</div>
                <h3 className="text-2xl md:text-3xl font-black uppercase text-brand-navy tracking-tight">Recicladora Green Resources</h3>
              </div>
            </div>
            <ul className="space-y-3 text-brand-mid mb-8 flex-1">
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-brand-mint-deep flex-shrink-0" />
                <span>Teléfono: <a href="tel:+18097296000" className="text-brand-navy font-bold link-underline">+1 809 729-6000</a></span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-brand-mint-deep flex-shrink-0" />
                <span>Email: <a href="mailto:info@recicladora.com.do" className="text-brand-navy font-bold link-underline">info@recicladora.com.do</a></span>
              </li>
              <li className="flex items-center gap-3">
                <MapPin size={18} className="text-brand-mint-deep flex-shrink-0" />
                <a href="https://maps.app.goo.gl/64zDPCHqxrNdWXEz7" target="_blank" rel="noopener noreferrer" className="link-underline">Km. 19 Autopista Duarte, Pedro Brand, SD Oeste</a>
              </li>
            </ul>
            <a
              href="mailto:info@recicladora.com.do"
              className="btn-base text-white self-start"
              style={{ background: "hsl(var(--mint-deep))", borderColor: "hsl(var(--mint-deep))" }}
            >
              Enviar correo <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </div>
    </section>
  </Layout>
);

export default Contacto;
