import { Link } from "react-router-dom";
import { ArrowRight, Network, FileCheck2, MapPin, Recycle, Ship } from "lucide-react";
import Layout from "@/components/Layout";
import heroShip from "@/assets/hero-ship.jpg";
import portChina from "@/assets/port-china.jpg";
import recyclingYard from "@/assets/recycling-yard.jpg";
import craneGrab from "@/assets/crane-grab.jpg";
import logoRgr from "@/assets/logo-recicladora.png";

const Index = () => {
  return (
    <Layout>
      {/* HERO — clean video + red overlay (no logo, no decorative shapes) */}
      <section className="relative h-[92vh] min-h-[640px] overflow-hidden">
        <video
          className="absolute inset-0 w-full h-full object-cover z-0"
          autoPlay muted loop playsInline poster={heroShip}
        >
          <source src="https://ik.imagekit.io/rqabtyp51t/0416.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-[hsl(var(--red))]/75 z-10" />

        <div className="relative z-30 container-x h-full flex flex-col justify-center text-white">
          <h1 className="text-white max-w-5xl animate-fade-in-up delay-150">
            Tu cadena<br />de importación,<br />
            <span className="text-brand-mint">gestionada de</span><br />
            <span className="text-brand-mint">principio a fin.</span>
          </h1>
          <p className="mt-8 max-w-2xl text-lg md:text-xl font-medium text-white/95 animate-fade-in-up delay-300 leading-relaxed">
            Conectamos empresas dominicanas con proveedores en China y comercializamos materiales reciclables a gran escala. Sin sorpresas. Sin intermediarios innecesarios.
          </p>
          <div className="mt-10 flex flex-wrap gap-4 animate-fade-in-up delay-450">
            <Link to="/bf-gesto-import" className="btn-white">
              Importar desde China <ArrowRight size={18} />
            </Link>
            <Link to="/recicladora" className="btn-outline-white">
              Gestión de Reciclaje <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* SOBRE NOSOTROS — RED block with image right */}
      <section className="relative bg-[hsl(var(--red))] text-white overflow-hidden py-24">
        <div className="relative container-x grid md:grid-cols-2 gap-14 items-center">
          <div>
            <div className="section-label !text-white/90">Quiénes somos</div>
            <h2 className="text-white mb-8">Sobre Nosotros</h2>
            <p className="text-lg leading-relaxed text-white/95 mb-6">
              BF Gesto es un grupo empresarial dominicano líder en la gestión de importaciones desde China y en la comercialización de materiales reciclables. Verificamos proveedores, garantizamos relaciones comerciales con socios confiables y operamos bajo un solo estándar de calidad.
            </p>
            <div className="h-px bg-white/30 my-6" />
            <p className="text-lg leading-relaxed text-white/95">
              Gestionamos envíos, permisos aduanales, almacenaje en China y alquiler de espacios en contenedores consolidados. Y, en paralelo, comercializamos chatarra ferrosa, no ferrosa, cartón y plásticos reciclados.
            </p>
          </div>
          <div className="relative">
            <img
              src={portChina}
              alt="Operación de importación en puerto"
              className="relative w-full h-[460px] object-cover rounded-l-[80px] shadow-2xl"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      {/* SERVICIOS — three icon medallions */}
      <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden border-t-4 border-white/10">
        <div className="container-x relative">
          <div className="text-center mb-16">
            <div className="section-label">Lo que hacemos</div>
            <h2 className="text-white">Servicios</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-10 md:gap-6 items-start">
            {[
              { Icon: FileCheck2, t: "Verificación de Proveedores", d: "Evaluación exhaustiva de la reputación, capacidad y fiabilidad de proveedores en China." },
              { Icon: Ship, t: "Gestión de Envíos", d: "Coordinación integral de envíos marítimos, aéreos y terrestres desde origen hasta destino." },
              { Icon: Network, t: "Gestiones Aduanales", d: "Documentación completa y manejo de trámites para importaciones fluidas y sin sorpresas." },
            ].map(({ Icon, t, d }, i) => (
              <div key={t} className="flex flex-col items-center text-center relative">
                <div className="icon-medallion mb-6">
                  <Icon size={36} strokeWidth={2} />
                </div>
                {i < 2 && (
                  <div className="hidden md:block absolute top-12 -right-4 text-white/60 text-2xl tracking-widest">
                    · · · · ▶
                  </div>
                )}
                <h3 className="text-white mb-3 text-xl">{t}</h3>
                <p className="text-white/90 text-sm md:text-base leading-relaxed max-w-xs">{d}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-14">
            <Link to="/bf-gesto-import" className="btn-white">
              Ver todos los servicios <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* DOS EMPRESAS — Light section with two cards */}
      <section id="empresas" className="relative bg-brand-off py-24 overflow-hidden">
        <div className="container-x relative">
          <div className="max-w-3xl mb-14">
            <div className="section-label" style={{ color: "hsl(var(--red))" }}>El grupo</div>
            <h2 className="text-brand-navy">Dos empresas.<br/>Un solo estándar.</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-stretch">
            {/* BF Gesto card */}
            <div className="card-light flex flex-col h-full p-0 border-l-[6px] border-brand-red overflow-hidden">
              <img src={portChina} alt="Puerto de importación" loading="lazy" className="w-full h-56 object-cover" />
              <div className="p-10 flex flex-col flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <div className="inline-flex items-center gap-2 border-2 border-brand-navy px-2.5 py-1.5 leading-none text-brand-navy">
                    <span className="block w-3.5 h-3.5 border-2 border-current" aria-hidden />
                    <span className="font-black uppercase tracking-[0.05em] text-[10px]">BF GESTO<br/>IMPORT</span>
                  </div>
                  <div className="text-xs font-extrabold uppercase tracking-[0.18em] text-brand-red">Importación · Logística · Reciclables</div>
                </div>
                <p className="text-brand-mid leading-relaxed mb-8 flex-1">
                  Verificamos proveedores, coordinamos envíos marítimos y aéreos, manejamos aduanas y comercializamos chatarra ferrosa, no ferrosa, cartón y plásticos reciclados.
                </p>
                <Link to="/bf-gesto-import" className="btn-red self-start">
                  Ver servicios <ArrowRight size={18} />
                </Link>
              </div>
            </div>

            {/* Recicladora card */}
            <div className="card-light flex flex-col h-full p-0 border-l-[6px] border-brand-mint-deep overflow-hidden">
              <img src={recyclingYard} alt="Patio de reciclaje" loading="lazy" className="w-full h-56 object-cover" />
              <div className="p-10 flex flex-col flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <img src={logoRgr} alt="Recicladora Green Resources" className="h-9 w-auto object-contain" />
                  <div className="text-xs font-extrabold uppercase tracking-[0.18em] text-brand-mint-deep">Reciclaje Industrial</div>
                </div>
                <p className="text-brand-mid leading-relaxed mb-8 flex-1">
                  Desde 2003 procesamos y exportamos metales ferrosos, no ferrosos, baterías húmedas y plásticos. Instalaciones de 5,000 m² en Santo Domingo Oeste.
                </p>
                <Link
                  to="/recicladora"
                  className="btn-base text-white self-start"
                  style={{ background: "hsl(var(--mint-deep))", borderColor: "hsl(var(--mint-deep))" }}
                >
                  Ver servicios <ArrowRight size={18} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS — red block, 3 columns */}
      <section className="relative bg-[hsl(var(--red))] text-white py-24 overflow-hidden border-t-4 border-white/10">
        <div className="container-x relative">
          <div className="grid md:grid-cols-3 gap-10 md:gap-8 text-center md:text-left">
            {[
              { n: "+20 años", t: "En operaciones de reciclaje industrial." },
              { n: "5,000 m²", t: "Instalaciones en Santo Domingo Oeste." },
              { n: "China → RD", t: "Cadena directa sin intermediarios innecesarios." },
            ].map((s) => (
              <div key={s.n} className="md:border-l-2 md:border-white/25 md:pl-8 first:md:border-l-0 first:md:pl-0">
                <div className="text-5xl md:text-6xl font-black uppercase tracking-tight text-white leading-none mb-4">{s.n}</div>
                <p className="text-white/90 text-base md:text-lg leading-relaxed font-medium">{s.t}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CÓMO OPERAMOS — numbered, presentation-style */}
      <section className="relative bg-white py-24 overflow-hidden">
        <div className="container-x">
          <div className="section-label" style={{ color: "hsl(var(--red))" }}>Cómo operamos</div>
          <h2 className="text-brand-navy max-w-3xl mb-16">Una forma de trabajar, dos industrias.</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { n: "01.", t: "Sin intermediarios", d: "Acceso directo a navieras, proveedores verificados y agentes aduanales. La cadena más corta posible.", Icon: Network },
              { n: "02.", t: "Procesos documentados", d: "Cada operación tiene trazabilidad. Sabes dónde está tu carga en todo momento.", Icon: FileCheck2 },
              { n: "03.", t: "Base en RD", d: "Operamos desde aquí. Entendemos la aduana local y los tiempos reales.", Icon: MapPin },
            ].map(({ n, t, d, Icon }) => (
              <div key={n} className="relative pt-2">
                <div className="flex items-start gap-4 mb-4">
                  <span className="step-number">{n}</span>
                  <Icon className="text-brand-red mt-3" size={28} strokeWidth={2} />
                </div>
                <h3 className="text-brand-navy mb-3 text-xl">{t}</h3>
                <p className="text-brand-mid leading-relaxed">{d}</p>
              </div>
            ))}
          </div>

          <div className="mt-14 text-center">
            <Link to="/contacto" className="btn-red">
              Solicitar servicio <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* RECICLAJE TEASER — navy with crane image */}
      <section className="relative bg-brand-navy text-white overflow-hidden">
        <div className="grid md:grid-cols-2 items-stretch">
          <div className="py-20 px-6 md:px-16 lg:px-24 flex flex-col justify-center">
            <Recycle className="text-brand-mint mb-4" size={40} />
            <h2 className="text-white mb-4">Reciclaje<br/>responsable.</h2>
            <p className="text-white/85 text-lg leading-relaxed mb-8">
              Más de 20 años procesando lo que la industria descarta. Cada tonelada que recuperamos es una decisión económica y ambiental al mismo tiempo.
            </p>
            <div className="grid grid-cols-2 gap-4 max-w-lg">
              {[
                ["74%", "menos energía"],
                ["86%", "menos polución del aire"],
                ["76%", "menos contaminación de agua"],
                ["40%", "menos consumo de agua"],
              ].map(([n, d]) => (
                <div key={n} className="bg-white/10 p-5 rounded-md border border-white/15">
                  <div className="text-3xl md:text-4xl font-black text-brand-mint leading-none mb-2">{n}</div>
                  <div className="text-xs text-white/80 uppercase tracking-wider font-bold">{d}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative min-h-[420px]">
            <img
              src={craneGrab}
              alt="Grúa de reciclaje industrial"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover"
            />
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
