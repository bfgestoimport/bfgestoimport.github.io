import logoBf from "@/assets/logo-bfgesto.jpg";

type Props = {
  /** When true, shows the BGESTO image asset inside the white pill (used in footer/select areas). */
  imageOnly?: boolean;
  className?: string;
  /** Force the text variant (default). On dark/red sections renders white outlined text. */
  variant?: "default" | "image";
};

/**
 * Brand emblem. Default = simple bordered text mark "BF GESTO / IMPORT" (matches screenshot).
 * variant="image" renders the BGESTO logo image (used only in footer / specific spots).
 */
const LogoPill = ({ imageOnly = false, className = "", variant = "default" }: Props) => {
  if (variant === "image" || imageOnly) {
    return (
      <div className={`inline-flex items-center bg-white px-3 py-2 rounded-md shadow-sm ${className}`}>
        <img src={logoBf} alt="BF Gesto Import" className="h-10 w-auto object-contain" />
      </div>
    );
  }
  return (
    <div
      className={`inline-flex items-center gap-2.5 border-2 border-current px-3 py-2 leading-none ${className}`}
    >
      <span className="block w-5 h-5 border-2 border-current" aria-hidden />
      <span className="font-black uppercase tracking-[0.05em] text-sm">
        BF GESTO
        <br />
        IMPORT
      </span>
    </div>
  );
};

export default LogoPill;
