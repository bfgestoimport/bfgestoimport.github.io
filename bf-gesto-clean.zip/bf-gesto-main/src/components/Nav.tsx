import { useState, useEffect, useRef } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";
import logoBf from "@/assets/logo-bfgesto.jpg";

const linkBase =
  "text-sm font-extrabold uppercase tracking-[0.14em] transition-colors duration-200 link-underline";

const Nav = () => {
  const [open, setOpen] = useState(false);
  const [empresasOpen, setEmpresasOpen] = useState(false);
  const location = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);

  const navClass = ({ isActive }: { isActive: boolean }) =>
    `${linkBase} ${isActive ? "text-brand-red active" : "text-brand-navy hover:text-brand-red"}`;

  const isEmpresasActive =
    location.pathname === "/bf-gesto-import" || location.pathname === "/recicladora";

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setEmpresasOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    setOpen(false);
    setEmpresasOpen(false);
  }, [location.pathname]);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border">
      <div className="container-x flex items-center justify-between h-20">
        <Link to="/" aria-label="BF Gesto Import — Inicio" className="inline-flex items-center transition-transform duration-200 hover:scale-105">
          <img src={logoBf} alt="BF Gesto Import" className="h-12 w-auto object-contain" />
        </Link>

        {/* Desktop */}
        <nav className="hidden md:flex items-center gap-10">
          <NavLink to="/" end className={navClass}>Inicio</NavLink>
          <NavLink to="/nosotros" className={navClass}>Nosotros</NavLink>
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setEmpresasOpen((v) => !v)}
              className={`${linkBase} flex items-center gap-1 ${isEmpresasActive ? "text-brand-red active" : "text-brand-navy hover:text-brand-red"}`}
              aria-expanded={empresasOpen}
            >
              Empresas <ChevronDown size={14} className={`transition-transform ${empresasOpen ? "rotate-180" : ""}`} />
            </button>
            {empresasOpen && (
              <div className="absolute top-full right-0 pt-3 w-72 animate-fade-in-up">
                <div className="bg-white border border-border shadow-lg rounded">
                  <NavLink
                    to="/bf-gesto-import"
                    className="block px-5 py-4 text-sm font-extrabold uppercase tracking-wider text-brand-navy hover:bg-brand-off hover:text-brand-red border-l-4 border-brand-red"
                  >
                    BF Gesto Import
                  </NavLink>
                  <NavLink
                    to="/recicladora"
                    className="block px-5 py-4 text-sm font-extrabold uppercase tracking-wider text-brand-navy hover:bg-brand-off hover:text-brand-mint-deep border-l-4 border-brand-mint-deep"
                  >
                    Recicladora Green Resources
                  </NavLink>
                </div>
              </div>
            )}
          </div>
          <NavLink to="/contacto" className={navClass}>Contacto</NavLink>
        </nav>

        <button
          className="md:hidden text-brand-navy"
          onClick={() => setOpen(!open)}
          aria-label="Menú"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-white border-t border-border">
          <div className="container-x py-6 flex flex-col gap-4">
            <NavLink to="/" end className={navClass}>Inicio</NavLink>
            <NavLink to="/nosotros" className={navClass}>Nosotros</NavLink>
            <div className="text-xs uppercase tracking-widest text-brand-mid mt-2">Empresas</div>
            <NavLink to="/bf-gesto-import" className={`${navClass} pl-3 border-l-4 border-brand-red`}>
              BF Gesto Import
            </NavLink>
            <NavLink to="/recicladora" className={`${navClass} pl-3 border-l-4 border-brand-mint-deep`}>
              Recicladora Green Resources
            </NavLink>
            <NavLink to="/contacto" className={navClass}>Contacto</NavLink>
          </div>
        </div>
      )}
    </header>
  );
};

export default Nav;
