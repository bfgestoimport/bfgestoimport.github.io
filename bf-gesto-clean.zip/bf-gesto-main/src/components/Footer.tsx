import { Link } from "react-router-dom";
import logoBf from "@/assets/logo-bfgesto.jpg";
import logoRgr from "@/assets/logo-recicladora.png";

const Footer = () => {
  return (
    <footer className="relative bg-[hsl(var(--red-dark))] text-white overflow-hidden">
      {/* Geometric corner shapes */}
      <div className="absolute top-0 right-0 w-40 h-24 blob-gold rounded-bl-[80px]" aria-hidden />
      <div className="absolute bottom-0 left-0 w-48 h-32 blob-burgundy rounded-tr-[80px]" aria-hidden />

      <div className="relative container-x py-24">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-10 mb-14">
          <div>
            <h2 className="text-white max-w-xl">Hablemos.<br/>Te tenemos una solución.</h2>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-stretch">
          {/* BF Gesto Import card */}
          <div className="bg-white/10 backdrop-blur-sm p-8 rounded-md border border-white/15 flex flex-col">
            <div className="text-xs uppercase tracking-[0.2em] text-brand-mint mb-3 font-extrabold">Importación · Logística</div>
            <div className="bg-white inline-flex p-2 rounded-sm mb-4 self-start">
              <img src={logoBf} alt="BF Gesto Import" className="h-10 w-auto object-contain" />
            </div>
            <h3 className="text-white mb-4">BF Gesto Import</h3>
            <p className="text-sm leading-relaxed mb-2 text-white/90">
              <a href="mailto:bfgestoimport@gmail.com" className="hover:text-white">bfgestoimport@gmail.com</a>
            </p>
            <p className="text-sm leading-relaxed mb-2 text-white/90">
              WhatsApp: <a href="https://wa.me/18297949216" target="_blank" rel="noopener noreferrer" className="hover:text-white">1-829-794-9216</a>
            </p>
            <p className="text-sm leading-relaxed mb-6 text-white/90">
              Instagram: <a href="https://instagram.com/bfgestoimport" target="_blank" rel="noopener noreferrer" className="hover:text-white">@bfgestoimport</a>
            </p>
            <Link to="/contacto" className="btn-white self-start mt-auto">
              Solicitar servicio
            </Link>
          </div>

          {/* Recicladora card */}
          <div className="bg-white/10 backdrop-blur-sm p-8 rounded-md border border-white/15 flex flex-col">
            <div className="text-xs uppercase tracking-[0.2em] text-brand-mint mb-3 font-extrabold">Reciclaje Industrial</div>
            <div className="bg-white inline-flex p-2 rounded-sm mb-4 self-start">
              <img src={logoRgr} alt="Recicladora Green Resources" className="h-10 w-auto object-contain" />
            </div>
            <h3 className="text-white mb-4">Recicladora Green Resources</h3>
            <p className="text-sm leading-relaxed mb-2 text-white/90">
              <a href="mailto:info@recicladora.com.do" className="hover:text-white">info@recicladora.com.do</a>
            </p>
            <p className="text-sm leading-relaxed mb-2 text-white/90">
              Tel: <a href="tel:+18097296000" className="hover:text-white">+1 809 729-6000</a>
            </p>
            <p className="text-sm leading-relaxed mb-6 text-white/90">Km. 19 Autopista Duarte, Pedro Brand, SD Oeste</p>
            <Link to="/contacto" className="btn-white self-start mt-auto">
              Solicitar servicio
            </Link>
          </div>
        </div>

        <div className="mt-16 pt-6 border-t border-white/20 text-center text-xs uppercase tracking-[0.2em] text-white/70 font-bold">
          © {new Date().getFullYear()} BF Gesto · Todos los derechos reservados ·{" "}
          <span className="normal-case tracking-normal font-medium">
            Creado por{" "}
            <a
              href="https://intrepidux.com"
              target="_blank"
              rel="noopener noreferrer"
              className="font-bold uppercase tracking-[0.15em] hover:text-white underline-offset-4 hover:underline"
            >
              Intrepidux
            </a>
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
